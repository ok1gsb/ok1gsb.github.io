MMANA 2.03 cesky
----------------

Instalace: Do adresare MMANA prekopirujte soubory czech.mmn
a mmnlanguage.txt (druhy soubor bude nutne prepsat). V nabidce
Service -> Language zvolte "czech".

V souboru Mamana.ini je treba zmenit font z puvodniho
Microsoft Sans Serif na MS Sans Serif, jinak se nezobrazuje
diakritika korektne.

Nektere klauzule nebylo mozne lokalizovat, nebot jsou "natvrdo"
zakodovany primo do programu. Doufejme, ze v pristi verzi to bude
odstraneno.